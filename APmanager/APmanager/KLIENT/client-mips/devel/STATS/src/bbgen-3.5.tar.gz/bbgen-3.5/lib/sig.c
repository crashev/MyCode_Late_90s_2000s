/*----------------------------------------------------------------------------*/
/* bbgen toolkit                                                              */
/*                                                                            */
/* This is a library module, part of libbbgen.                                */
/* It contains routines for handling of signals and crashes.                  */
/*                                                                            */
/* Copyright (C) 2002-2004 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char rcsid[] = "$Id: sig.c,v 1.3 2004/11/18 14:11:07 henrik Exp $";

#include <limits.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

#include "sig.h"

/* Data used while crashing - cannot depend on the stack being usable */
static char signal_bbcmd[PATH_MAX];
static char signal_bbdisp[1024];
static char signal_msg[1024];
static char signal_bbtmp[PATH_MAX];


static void sigsegv_handler(int signum)
{
	/*
	 * This is a signal handler. Only a very limited number of 
	 * library routines can be safely used here, according to
	 * Posix: http://www.opengroup.org/onlinepubs/007904975/functions/xsh_chap02_04.html#tag_02_04_03
	 * Do not use string, stdio etc. - just basic system calls.
	 * That is why we need to setup all of the strings in advance.
	 */

	signal(signum, SIG_DFL);

	/* 
	 * Try to fork a child to send in an alarm message.
	 * If the fork fails, then just attempt to exec() the BB command
	 */
	if (fork() <= 0) {
		execl(signal_bbcmd, "bbgen-signal", signal_bbdisp, signal_msg, NULL);
	}

	/* Dump core and abort */
	chdir(signal_bbtmp);
	abort();
}

void setup_signalhandler(char *programname)
{
	struct rlimit lim;
	struct sigaction sa;

	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sigsegv_handler;

	/*
	 * After lengthy debugging and perusing of mail archives:
	 * Need to ignore SIGPIPE since FreeBSD (and others?) can throw this
	 * on a write() instead of simply returning -EPIPE like any sane
	 * OS would.
	 */
	signal(SIGPIPE, SIG_IGN);

	/*
	 * Try to allow ourselves to generate core files
	 */
	getrlimit(RLIMIT_CORE, &lim);
	lim.rlim_cur = RLIM_INFINITY;
	setrlimit(RLIMIT_CORE, &lim);

	if (getenv("BB") == NULL) return;
	if (getenv("BBDISP") == NULL) return;

	/*
	 * Used inside signal-handler. Must be setup in
	 * advance.
	 */
	strcpy(signal_bbcmd, getenv("BB"));
	strcpy(signal_bbdisp, getenv("BBDISP"));
	strcpy(signal_bbtmp, getenv("BBTMP"));
	sprintf(signal_msg, "status %s.%s red - Program crashed\n\nFatal signal caught!\n", 
		(getenv("MACHINE") ? getenv("MACHINE") : "BBDISPLAY"), programname);

	sigaction(SIGSEGV, &sa, NULL);
#ifdef SIGBUS
	sigaction(SIGBUS, &sa, NULL);
#endif
}



