/*----------------------------------------------------------------------------*/
/* Big Brother webpage generator tool.                                        */
/*                                                                            */
/* This is a replacement for the "mkbb.sh" and "mkbb2.sh" scripts from the    */
/* "Big Brother" monitoring tool from BB4 Technologies.                       */
/*                                                                            */
/* Primary reason for doing this: Shell scripts perform badly, and with a     */
/* medium-sized installation (~150 hosts) it takes several minutes to         */
/* generate the webpages. This is a problem, when the pages are used for      */
/* 24x7 monitoring of the system status.                                      */
/*                                                                            */
/* Copyright (C) 2002 Henrik Storner <henrik@storner.dk>                      */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char rcsid[] = "$Id: alert.c,v 1.22 2004/10/30 15:35:21 henrik Exp $";

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "bbgen.h"
#include "alert.h"

typedef struct alertgroup_t {
	char *groupname;
	char *groupval;
	struct alertgroup_t *next;
} alertgroup_t;

static alertgroup_t *pagegroups = NULL;
static alertgroup_t *hostgroups = NULL;
static alertrec_t   *alertrecs = NULL;
static alertrec_t   *unmatched = NULL;

static char cfgdelim = ';';
char ignforall[MAX_LINE_LEN];
int pagedelay = 0;


static alertgroup_t *findalertgroup(alertgroup_t *head, char *key)
{
	alertgroup_t *l;

	for (l = head; (l && (strcmp(l->groupname, key) != 0)); l = l->next) ;

	return l;
}


static void load_warnsetup(void)
{
	FILE *fd;
	char fn[PATH_MAX];
	char *p;
	struct linebuf_t lbuf;
	char *l;

	sprintf(fn, "%s/etc/bbwarnsetup.cfg", getenv("BBHOME"));
	fd = fopen(fn, "r");
	if (fd == NULL) {
		errprintf("Cannot open %s\n", fn);
		return;
	}

	lbuf.buf = NULL; lbuf.buflen = 0;

	while (read_line(&lbuf, fd)) {
		l = lbuf.buf;

		/* Strip trailing whitespace */
		for (p = l + strlen(l) - 1; ((p > l) && isspace((int) *p)); p--) *p = '\0';

		if ((strncmp(l, "pg-", 3) == 0) || (strncmp(l, "hg-", 3) == 0)) {
			alertgroup_t *newgroup;
			char *q;

			p = strchr(l, ':');
			if (p) {
				newgroup = (alertgroup_t *) malloc(sizeof(alertgroup_t));
				for (q = p-1; ((q > l) && (isspace((int) *q))); q--) ;
				*(q+1) = '\0';
				newgroup->groupname = strdup(l);

				for (p++; (*p && isspace((int) *p)); p++) ;
				newgroup->groupval = strdup(p);

				if (strncmp(l, "pg-", 3) == 0) {
					newgroup->next = pagegroups;
					pagegroups = newgroup;
				}
				else {
					newgroup->next = hostgroups;
					hostgroups = newgroup;
				}
			}
		}
		else if (strncmp(l, "cfgdelim", 8) == 0) {
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p && *p) cfgdelim = *p;
		}
		else if (strncmp(l, "ignforall", 9) == 0) {
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p) strcpy(ignforall, p);
		}
		else if (strncmp(l, "pagedelay", 9) == 0) {
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p) pagedelay = atoi(p);
		}
	}

	fclose(fd);
	if (lbuf.buf) free(lbuf.buf);
}

static void load_warnrules(void)
{
	FILE *fd;
	char fn[PATH_MAX];
	char *p, *q;
	int i, inverse;
	struct linebuf_t lbuf;
	char *l;

	sprintf(fn, "%s/etc/bbwarnrules.cfg", getenv("BBHOME"));
	fd = fopen(fn, "r");
	if (fd == NULL) {
		errprintf("Cannot open %s\n", fn);
		return;
	}

	lbuf.buf = NULL; lbuf.buflen = 0;

	while (read_line(&lbuf, fd)) {
		l = lbuf.buf;
		inverse = (*l == '!'); if (inverse) l++;

		/* Strip trailing whitespace */
		for (p = l + strlen(l) - 1; ((p > l) && isspace((int) *p)); p--) *p = '\0';

		if (strlen(l) && (isalpha((int) *l) || (*l == '.') || (*l == '*'))) {
			alertrec_t *newalert = (alertrec_t *) malloc(sizeof(alertrec_t));
			int valid=1;

			for (i=0; i<7; i++) newalert->items[i] = NULL;
			dprintf("Doing line '%s'\n", l);

			for (p=l, i=0; (p && (i<7) && valid); i++) {
				q = strchr(p, cfgdelim);
				if (q) {
					*q = '\0';
					newalert->items[i] = strdup(p);
					dprintf("  Item %d=%s\n", i, p);
					p = q+1;
				}
				else {
					if (i==6) {
						newalert->items[i] = strdup(p);
						dprintf("  Item 6=%s\n", p);
						p = NULL;
					}
					else {
						dprintf("  Invalid line\n");
						valid=0;
					}
				}
			}

			if (valid) {
				newalert->inverse = inverse;
				newalert->next = alertrecs;
				alertrecs = newalert;

				if (strcmp(newalert->items[0], "unmatched-*") == 0) unmatched = newalert;
			}
			else {
				errprintf("bbwarnrules.cfg: Syntax error in '%s' definition\n", l);
			}
		}
	}

	fclose(fd);

	if (lbuf.buf) free(lbuf.buf);
}


static void replace_groupnames(int itemidx, char *prefix, int lookforcolon, alertgroup_t *head)
{
	/*
	 * The purpose of this routine is to replace the hg-/pg- specs in a
	 * alert rule with the corresponding host- or recipients.
	 * The hg replacement is needed to determine which rule matches a
	 * given host.
	 * The pg replacement is done to be able to see the actual recipients
	 * of an alert on the info page.
	 *
	 * The "itemidx" is 
	 * - 0 : Replace the hg specs in the "included hosts" setting
	 * - 1 : Replace the hg specs in the "excluded hosts" setting
	 * - 6 : Replace the pg specs
	 *
	 * "lookforcolon" is true only when replacing pg specs
	 */

	alertrec_t *a;
	alertgroup_t *group;
	char *p, *q;
	char newval[MAX_LINE_LEN];
	char v1[MAX_LINE_LEN], v2[MAX_LINE_LEN];

	for (a=alertrecs; (a); a=a->next) {
		newval[0] = '\0';
		strcpy(v1, a->items[itemidx]);

		p = strtok(v1, " \t");

		if (p) dprintf("replace_groupnames(%d, %s, %d) replacing in '%s'\n", 
		 		itemidx, prefix, lookforcolon, a->items[itemidx]);

		while (p) {
			dprintf("-> item '%s', strlen(newval)=%d\n", p, strlen(newval));

			if (strncmp(p, prefix, strlen(prefix)) == 0) {

				/* This is a hg/pg item */

				q = NULL;
				if (lookforcolon && ((q = strchr(p, ':')) != NULL)) 
					*q = '\0';

				group = findalertgroup(head, p);
				if (group) {
					dprintf("   -> search for group '%s' returned '%s'\n", p, textornull(group->groupval));

					if (q) {
						char *item;
						char *tokbuf2;

						/* 
						 * This is a pg-* item that has modifiers on it.
						 * We need to modify each item in the expanded list.
						 * 'q' points to the modifiers.
						 */

						*q = ':';
						strcpy(v2, group->groupval);
						tokbuf2 = (char *) malloc(strlen(v2)+1024);
						item = strtok_r(v2, " \t", &tokbuf2);
						while (item) {
							if (strlen(newval)) strcat(newval, " ");
							strcat(newval, item);
							strcat(newval, q);
							item = strtok_r(NULL, " ", &tokbuf2);
						}
					}
					else { 
						/* Replace hg/pg item with the group value */
						strcat(newval, group->groupval);
					}
				}
				else {
					/* It's a hg/pg item, but we have no such group */
					dprintf("   -> search for group '%s' failed \n", p);
					if (strlen(newval)) strcat(newval, " ");
					strcat(newval, p);
					strcat(newval, " (undefined group)");
				}
			}
			else {
				/* Simple spec - no hg/pg replacing needed */
				if (strlen(newval)) strcat(newval, " ");
				strcat(newval, p);
			}

			p = strtok(NULL, " ");
		}

		if (strcmp(a->items[itemidx], newval) != 0) {
			free(a->items[itemidx]);
			a->items[itemidx] = strdup(newval);
		}
	}
}

static void setup_regexps(int itemidx)
{
	alertrec_t *a;
	char *p, *q;
	int status;
	char rgp[MAX_LINE_LEN];

	for (a=alertrecs; (a); a=a->next) {
		for (p=a->items[itemidx], rgp[0]='^', q=&rgp[1]; (*p); p++) {
			switch (*p) {
				case ' ': 
				case '\t':
					*q = '|'; *(q+1) = '^'; q+=2;
					/* Avoid bad things happening if two spaces follow each other */
					while (*(p+1) && isspace((int) *(p+1))) p++;
					break;
				case '*':
					*q = '.'; *(q+1) = '*'; q+=2;
					break;
				default:
					*q = *p; q++;
			}
		}
		*q = 0;

		if (strlen(a->items[itemidx])) {
			status = regcomp(&a->hostpattern[itemidx], rgp, REG_EXTENDED|REG_NOSUB);
			if (status) errprintf("regexp compile failed for expression %s\n", rgp);
		}

	}
}


void load_alerts(void)
{
	load_warnsetup();
	load_warnrules();
	replace_groupnames(0, "hg-", 0, hostgroups); /* Replace hg-* in "included hosts" spec. */
	replace_groupnames(1, "hg-", 0, hostgroups); /* Replace hg-* in "excluded hosts" spec. */
	replace_groupnames(6, "pg-", 1, pagegroups); /* Replace pg-* in recipients spec. */
	setup_regexps(0);
	setup_regexps(1);
}


alertrec_t *find_alert(char *hostname, int want_default, int continued)
{
	static alertrec_t *beginrec = NULL;

	alertrec_t *a;
	regmatch_t foo[1];
	alertrec_t *result = NULL;
	int status;

	if (!continued || (beginrec == NULL)) 
		beginrec = alertrecs;
	else
		beginrec = beginrec->next;

	for (a=beginrec; (a && (result == NULL)); a=a->next) {
		dprintf("Checking '%s' against includespec '%s' excludespec '%s'\n",
			hostname, a->items[0], a->items[1]);
		status = regexec(&a->hostpattern[0], hostname, 0, foo, 0);
		if (status == 0) {
			dprintf("\tMatched include spec\n");
			result = a;
		}

		if (result && strlen(a->items[1])) {
			status = regexec(&a->hostpattern[1], hostname, 0, foo, 0);
			if (status == 0) {
				dprintf("\tMatched exclude spec\n");
				result = NULL;
			}
		}
	}

	beginrec = result;

	if ((result == NULL) && want_default) result = unmatched;
	return result;
}


#ifdef STANDALONE
int main(int argc, char *argv[])
{
	alertrec_t *a;
	int i, firstarg;

	debug = 0; firstarg = 1;
	if ((argc > 1) && (strcmp(argv[1], "--debug") == 0)) {
		debug = 1;
		firstarg++;
	}

	load_alerts();

	for (i=firstarg; (i<argc); i++) {
		int again = 0;
		while ((a = find_alert(argv[i], 0, again)) != NULL) {
			printf("  Key        : %s\n", argv[i]);
			printf("  Hosts      : %s\n", a->items[0]);
			printf("  Ex-hosts   : %s\n", a->items[1]);
			printf("  Services   : %s\n", a->items[2]);
			printf("  Ex-Services: %s\n", a->items[3]);
			printf("  Day        : %s\n", a->items[4]);
			printf("  Time       : %s\n", a->items[5]);
			printf("  Recips     : %s\n", a->items[6]);
			printf("  Inverse    : %d\n", a->inverse);
			printf("\n");
			again = 1;
		}
		if (again == 0) printf("No matches\n");
	}
	return 0;
}
#endif

