#!/usr/bin/perl
# bbgen-larrd.pl: larrd module to report bbgen run time
#
# based on other larrd script from :
# Scott Walters Copyright 1999
# scott@PacketPushers.com 
#  
# Christian Pearce
# pearcec@PacketPushers.com
#
# Adapted to bbgen by Christian Perrier <bubulle@kheops.frmug.org>
#$ENV{'DEBUG'}=1;


# this is for after install
use lib $ENV{'RRDPM'};
use RRDs;

#$ENV{'DEBUG'} = 1;

##################################
# SETUP
##################################

# 1. Define the extention for the metric

$ds = "bbgen";
@ds = ("DS:runtime:GAUGE:600:1:U");

##################################
# Start of script
##################################

if( not $ENV{'BBHOME'} ) {
        print "$0: BBHOME is not set\n";
        exit(1);
}

if( not -d $ENV{'BBHOME'} ) {
        print "$0: BBHOME is invalid\n";
        exit(1);
}

if( not -d $ENV{'BBRRDS'} ) {
        print "$0: BBRRDS is not set\n";
        exit(1);
}

##
# real work begins here
##

# Glob the bind logs
my %h_fn;

# Perl Cookbook Recipe 9.5
opendir(DIR, "$ENV{'BBLOGS'}") or die "$0: $!";
while ( defined($log = readdir(DIR))) {
        next unless $log =~ /\.$ds$/io;
        my $host = $log;
        $host =~ s/\.$ds//;
        $host =~ s/\,/\./g;

        $h_fn{$host}="$ENV{'BBLOGS'}/$log";
}
closedir(DIR);

while ( ($host,$log) = each %h_fn ) {


        print "$0 : DEBUG log=$log\n" if ($ENV{'DEBUG'});

	open(LOG,"$log");
	
        $temp = <LOG> if $log =~ /$ENV{'BBLOGS'}/io;

# 3. grab the timpstamp for rrd. 

	# Sometimes you get it from stat sometimes you get it from the log
        ($ctime) = (stat($log))[10];
	print "$0 : DEBUG ctime = $ctime\n" if ($ENV{'DEBUG'});

# 2. Grab the data from the log how ever you need

	open(LOG,"$log");
        @log=<LOG>;
        close(LOG);

foreach $line (@log) {

	# Throw away lines that are not data
		next if ($line !~/TIME TOTAL/);
	    
	# Removed any HTML tags
	$line =~ s/<.*>//g;
	print "$0: DEBUG $line\n" if $ENV{'DEBUG'};

	@col = split " ",$line;


# 4. create the rrd filename

        $RRD="$ENV{'BBRRDS'}/$host.$ds.rrd";

        print "$0 : RRD=$RRD\n" if ($ENV{'DEBUG'});

	# see if the RRD is around, if not make it	
	if ( not -f $RRD ) {
		
		# keeping this much disk data seems overkill
		# but thought 'standardizing' RRD's would be worth it
		# 30 seconds....
		@rras = split " ",$ENV{'RRAS'};
		RRDs::create($RRD,@ds,@rras);
		$ERR=RRDs::error;
		if($ERR) {
			print "$0: ERROR creating $RRD: $ERR\n" if ($ENV{'ERROR'});
			next; #does this work? yup!
		}
		$ctime="N";
		print "$0: STATUS did not find $RRD, created.\n" if ($ENV{'STATUS'});
	}

# 5. Put your data from step 2 to the rrd

	# now update the RRD
	RRDs::update("$RRD","$ctime:$col[2]");
        $ERR=RRDs::error;
        if($ERR) {
                print "$0: WARN updating $RRD: $ERR\n" if ($ENV{'WARN'})
;
        }

}	
        print "$0 : DEBUG unlink log=$log\n" if ($ENV{'DEBUG'});
unlink $log if $log =~ /$ENV{'BBVAR'}\/data/io;
}

##############################################
# end of script
##############################################

