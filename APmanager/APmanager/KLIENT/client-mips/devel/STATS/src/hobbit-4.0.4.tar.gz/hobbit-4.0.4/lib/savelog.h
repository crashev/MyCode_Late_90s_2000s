/*----------------------------------------------------------------------------*/
/* Hobbit monitor library.                                                    */
/*                                                                            */
/* Copyright (C) 2002-2005 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#ifndef __SAVELOG_H__
#define __SAVELOG_H__
extern int do_savelog(char *hostname, char *testname, char *ip, char *buffer, int hobbitd);
extern int do_savemeta(char *hostname, char *testname, char *metaname, char *buffer);
#endif
