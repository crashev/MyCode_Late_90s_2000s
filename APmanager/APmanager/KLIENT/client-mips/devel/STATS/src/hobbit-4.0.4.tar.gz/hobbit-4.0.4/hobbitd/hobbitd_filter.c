/*----------------------------------------------------------------------------*/
/* Hobbit message daemon.                                                     */
/*                                                                            */
/* Filter for incoming messages.                                              */
/* This module is invoked when a new status message is received, but          */
/* before it is handled by the daemon. The message is passed from             */
/* hobbitd in shared memory, so this filter can modify the message e.g.       */
/* change the color of the message based on some criteria.                    */
/*                                                                            */
/* Copyright (C) 2004-2005 Henrik Storner <henrik@hswn.dk>                    */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char rcsid[] = "$Id: hobbitd_filter.c,v 1.4 2005/05/07 09:24:20 henrik Exp $";

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "libbbgen.h"

#include "hobbitd_ipc.h"


static volatile int running = 1;
static volatile int gotalarm = 0;
static volatile int dologswitch = 0;
hobbitd_channel_t *channel = NULL;

void sig_handler(int signum)
{
	switch (signum) {
	  case SIGTERM:
	  case SIGINT:
		running = 0;
		break;

	  case SIGALRM:
		gotalarm = 1;
		break;

	  case SIGHUP:
		dologswitch = 1;
		break;
	}
}

int main(int argc, char *argv[])
{
	int argi, n;
	int daemonize = 0;
	char *logfn = NULL;
	char *envarea = NULL;
	struct sigaction sa;
	struct sembuf s;

	/* Dont save the error buffer */
	save_errbuf = 0;

	for (argi=1; (argi < argc); argi++) {
		if (argnmatch(argv[argi], "--debug")) {
			debug = 1;
		}
		else if (argnmatch(argv[argi], "--daemon")) {
			daemonize = 1;
		}
		else if (argnmatch(argv[argi], "--no-daemon")) {
			daemonize = 0;
		}
		else if (argnmatch(argv[argi], "--log=")) {
			char *p = strchr(argv[argi], '=');
			logfn = strdup(p+1);
		}
		else if (argnmatch(argv[argi], "--env=")) {
			char *p = strchr(argv[argi], '=');
			loadenv(p+1, envarea);
		}
		else if (argnmatch(argv[argi], "--area=")) {
			char *p = strchr(argv[argi], '=');
			envarea = strdup(p+1);
		}
	}

	/* Go daemon */
	if (daemonize) {
		/* Become a daemon */
		pid_t childpid = fork();
		if (childpid < 0) {
			/* Fork failed */
			errprintf("Could not fork child\n");
			exit(1);
		}
		else if (childpid > 0) {
			/* Parent exits */
			exit(0);
		}
		/* Child (daemon) continues here */
		setsid();
	}

	/* Catch signals */
	setup_signalhandler("hobbitd_channel");
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sig_handler;
	sigaction(SIGINT, &sa, NULL);
	sigaction(SIGTERM, &sa, NULL);
	sigaction(SIGHUP, &sa, NULL);

	/* Switch stdout/stderr to the logfile, if one was specified */
	freopen("/dev/null", "r", stdin);	/* stdin is not used */
	if (logfn) {
		freopen(logfn, "a", stdout);
		freopen(logfn, "a", stderr);
	}

	/* Attach to the status channel */
	channel = setup_channel(C_STATUS, CHAN_CLIENT);
	if (channel == NULL) {
		errprintf("Channel not available\n");
		return 1;
	}

	while (running) {

		if (dologswitch) {
			freopen(logfn, "a", stdout);
			freopen(logfn, "a", stderr);
			dologswitch = 0;
		}

		/* 
		 * Wait for GOCLIENT to go up.
		 */
		s.sem_num = GOCLIENT; s.sem_op  = -1; s.sem_flg = 0;
		n = semop(channel->semid, &s, 1);

		if (n == 0) {
			/*
			 * GOCLIENT went high, and so we got alerted about a new message arriving.
			 */

			/* Process the message */
			{
				char *p = strstr(channel->channelbuf, "|test|");

				if (p) memcpy(p, "|TEST|", 6);
			}

			/* 
			 * Wait until any other clients on the same channel have picked up 
			 * this message (GOCLIENT reaches 0).
			 *
			 * We wrap this into an alarm handler, because it can occasionally
			 * fail, causing the whole system to lock up. We dont want that....
			 */
			gotalarm = 0; signal(SIGALRM, sig_handler); alarm(2);
			do {
				s.sem_num = GOCLIENT; s.sem_op  = 0; s.sem_flg = 0;
				n = semop(channel->semid, &s, 1);
			} while ((n == -1) && (errno == EAGAIN) && running && (!gotalarm));
			signal(SIGALRM, SIG_IGN);

			if (gotalarm) {
				errprintf("Broke deadlock waiting for GOCLIENT to go low.\n");
			}

			/* 
			 * Let master know we got it by downing BOARDBUSY.
			 * This should not block, since BOARDBUSY is upped
			 * by the master just before he ups GOCLIENT.
			 */
			s.sem_num = BOARDBUSY; s.sem_op  = -1; s.sem_flg = 0;
			n = semop(channel->semid, &s, 1);
		}
		else {
			if (errno != EAGAIN) {
				dprintf("Semaphore wait aborted: %s\n", strerror(errno));
				continue;
			}
		}

	}

	/* Detach from channels */
	close_channel(channel, CHAN_CLIENT);

	return 0;
}

