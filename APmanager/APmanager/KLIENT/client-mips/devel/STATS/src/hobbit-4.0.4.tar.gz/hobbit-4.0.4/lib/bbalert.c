/*----------------------------------------------------------------------------*/
/* Hobbit monitor library.                                                    */
/*                                                                            */
/* This is a library module, part of libbbgen.                                */
/* It contains routines for reading and using the BB alert configuration.     */
/*                                                                            */
/* Copyright (C) 2002-2005 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char rcsid[] = "$Id: bbalert.c,v 1.29 2005/03/22 09:16:49 henrik Exp $";

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "libbbgen.h"

#include "bbalert.h"

typedef struct alertgroup_t {
	char *groupname;
	char *groupval;
	struct alertgroup_t *next;
} alertgroup_t;

static alertgroup_t *pagegroups = NULL;
static alertgroup_t *hostgroups = NULL;
static alertrec_t   *alertrecs = NULL;
static alertrec_t   *unmatched = NULL;

static char cfgdelim = ';';
static char *ignforall = NULL;
int bbpagedelay = 0;


static alertgroup_t *findalertgroup(alertgroup_t *head, char *key)
{
	alertgroup_t *l;

	for (l = head; (l && (strcmp(l->groupname, key) != 0)); l = l->next) ;

	return l;
}


static void load_warnsetup(void)
{
	FILE *fd;
	char fn[PATH_MAX];
	char *p;
	struct linebuf_t lbuf;
	char *l;

	MEMDEFINE(fn);

	sprintf(fn, "%s/etc/bbwarnsetup.cfg", xgetenv("BBHOME"));
	fd = fopen(fn, "r");
	if (fd == NULL) {
		MEMUNDEFINE(fn);
		errprintf("Cannot open %s\n", fn);
		return;
	}

	lbuf.buf = NULL; lbuf.buflen = 0;

	while (read_line(&lbuf, fd)) {
		l = lbuf.buf;

		/* Strip trailing whitespace */
		for (p = l + strlen(l) - 1; ((p > l) && isspace((int) *p)); p--) *p = '\0';

		if ((strncmp(l, "pg-", 3) == 0) || (strncmp(l, "hg-", 3) == 0)) {
			alertgroup_t *newgroup;
			char *q;

			p = strchr(l, ':');
			if (p) {
				newgroup = (alertgroup_t *) malloc(sizeof(alertgroup_t));
				for (q = p-1; ((q > l) && (isspace((int) *q))); q--) ;
				*(q+1) = '\0';
				newgroup->groupname = strdup(l);

				for (p++; (*p && isspace((int) *p)); p++) ;
				newgroup->groupval = strdup(p);

				if (strncmp(l, "pg-", 3) == 0) {
					newgroup->next = pagegroups;
					pagegroups = newgroup;
				}
				else {
					newgroup->next = hostgroups;
					hostgroups = newgroup;
				}
			}
		}
		else if (strncmp(l, "cfgdelim", 8) == 0) {
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p && *p) cfgdelim = *p;
		}
		else if (strncmp(l, "ignforall", 9) == 0) {
			if (ignforall) xfree(ignforall);
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p) ignforall = strdup(p);
		}
		else if (strncmp(l, "pagedelay", 9) == 0) {
			p = strchr(l, ':'); if (p) p++;
			for (; (p && *p && isspace((int) *p)); p++) ;
			if (p) bbpagedelay = atoi(p);
		}
	}

	fclose(fd);
	if (lbuf.buf) xfree(lbuf.buf);

	MEMUNDEFINE(fn);
}

static void load_warnrules(void)
{
	FILE *fd;
	char fn[PATH_MAX];
	char *p, *q;
	int i, inverse;
	struct linebuf_t lbuf;
	char *l;

	MEMDEFINE(fn);

	sprintf(fn, "%s/etc/bbwarnrules.cfg", xgetenv("BBHOME"));
	fd = fopen(fn, "r");
	if (fd == NULL) {
		errprintf("Cannot open %s\n", fn);

		MEMUNDEFINE(fn);
		return;
	}

	lbuf.buf = NULL; lbuf.buflen = 0;

	while (read_line(&lbuf, fd)) {
		l = lbuf.buf;
		inverse = (*l == '!'); if (inverse) l++;

		/* Strip trailing whitespace */
		for (p = l + strlen(l) - 1; ((p > l) && isspace((int) *p)); p--) *p = '\0';

		if (strlen(l) && (isalpha((int) *l) || (*l == '.') || (*l == '*'))) {
			alertrec_t *newalert = (alertrec_t *) calloc(1, sizeof(alertrec_t));
			int valid=1;

			for (i=0; i<7; i++) newalert->items[i] = NULL;
			dprintf("Doing line '%s'\n", l);

			for (p=l, i=0; (p && (i<7) && valid); i++) {
				q = strchr(p, cfgdelim);
				if (q) {
					*q = '\0';
					newalert->items[i] = strdup(p);
					dprintf("  Item %d=%s\n", i, p);
					p = q+1;
				}
				else {
					if (i==6) {
						newalert->items[i] = strdup(p);
						dprintf("  Item 6=%s\n", p);
						p = NULL;
					}
					else {
						dprintf("  Invalid line\n");
						valid=0;
					}
				}
			}

			if (valid) {
				newalert->inverse = inverse;
				newalert->next = alertrecs;
				alertrecs = newalert;

				if (strcmp(newalert->items[0], "unmatched-*") == 0) unmatched = newalert;
			}
			else {
				errprintf("bbwarnrules.cfg: Syntax error in '%s' definition\n", l);
			}
		}
	}

	fclose(fd);

	if (lbuf.buf) xfree(lbuf.buf);

	MEMUNDEFINE(fn);
}


static void replace_groupnames(int itemidx, char *prefix, int lookforcolon, alertgroup_t *head)
{
	/*
	 * The purpose of this routine is to replace the hg-/pg- specs in a
	 * alert rule with the corresponding host- or recipients.
	 * The hg replacement is needed to determine which rule matches a
	 * given host.
	 * The pg replacement is done to be able to see the actual recipients
	 * of an alert on the info page.
	 *
	 * The "itemidx" is 
	 * - 0 : Replace the hg specs in the "included hosts" setting
	 * - 1 : Replace the hg specs in the "excluded hosts" setting
	 * - 6 : Replace the pg specs
	 *
	 * "lookforcolon" is true only when replacing pg specs
	 */

	alertrec_t *a;
	alertgroup_t *group;
	char *p, *q;
	char newval[MAX_LINE_LEN];
	char v1[MAX_LINE_LEN], v2[MAX_LINE_LEN];

	MEMDEFINE(newval);
	MEMDEFINE(v1);
	MEMDEFINE(v2);

	for (a=alertrecs; (a); a=a->next) {
		newval[0] = '\0';
		strcpy(v1, a->items[itemidx]);

		p = strtok(v1, " \t");

		if (p) dprintf("replace_groupnames(%d, %s, %d) replacing in '%s'\n", 
		 		itemidx, prefix, lookforcolon, a->items[itemidx]);

		while (p) {
			dprintf("-> item '%s', strlen(newval)=%d\n", p, strlen(newval));

			if (strncmp(p, prefix, strlen(prefix)) == 0) {

				/* This is a hg/pg item */

				q = NULL;
				if (lookforcolon && ((q = strchr(p, ':')) != NULL)) 
					*q = '\0';

				group = findalertgroup(head, p);
				if (group) {
					dprintf("   -> search for group '%s' returned '%s'\n", p, textornull(group->groupval));

					if (q) {
						char *item;
						char *tokbuf2;

						/* 
						 * This is a pg-* item that has modifiers on it.
						 * We need to modify each item in the expanded list.
						 * 'q' points to the modifiers.
						 */

						*q = ':';
						strcpy(v2, group->groupval);
						tokbuf2 = (char *) malloc(strlen(v2)+1024);
						item = strtok_r(v2, " \t", &tokbuf2);
						while (item) {
							if (strlen(newval)) strcat(newval, " ");
							strcat(newval, item);
							strcat(newval, q);
							item = strtok_r(NULL, " ", &tokbuf2);
						}
					}
					else { 
						/* Replace hg/pg item with the group value */
						strcat(newval, group->groupval);
					}
				}
				else {
					/* It's a hg/pg item, but we have no such group */
					dprintf("   -> search for group '%s' failed \n", p);
					if (strlen(newval)) strcat(newval, " ");
					strcat(newval, p);
					strcat(newval, " (undefined group)");
				}
			}
			else {
				/* Simple spec - no hg/pg replacing needed */
				if (strlen(newval)) strcat(newval, " ");
				strcat(newval, p);
			}

			p = strtok(NULL, " ");
		}

		if (strcmp(a->items[itemidx], newval) != 0) {
			xfree(a->items[itemidx]);
			a->items[itemidx] = strdup(newval);
		}
	}

	MEMUNDEFINE(newval);
	MEMUNDEFINE(v1);
	MEMUNDEFINE(v2);
}

static void setup_regexps(int itemidx)
{
	alertrec_t *a;
	char *p, *q;
	int status;
	char rgp[MAX_LINE_LEN];

	MEMDEFINE(rgp);

	for (a=alertrecs; (a); a=a->next) {
		for (p=a->items[itemidx], rgp[0]='^', q=&rgp[1]; (*p); p++) {
			switch (*p) {
				case ' ': 
				case '\t':
					*q = '|'; *(q+1) = '^'; q+=2;
					/* Avoid bad things happening if two spaces follow each other */
					while (*(p+1) && isspace((int) *(p+1))) p++;
					break;
				case '*':
					*q = '.'; *(q+1) = '*'; q+=2;
					break;
				default:
					*q = *p; q++;
			}
		}
		*q = 0;

		if (strlen(a->items[itemidx])) {
			status = regcomp(&a->hostpattern[itemidx], rgp, REG_EXTENDED|REG_NOSUB);
			a->havepattern[itemidx] = (status == 0);
			if (status) errprintf("regexp compile failed for expression %s\n", rgp);
		}

	}

	MEMUNDEFINE(rgp);
}


void bbload_alerts(void)
{
	static time_t tstamp_setup = 0;
	static time_t tstamp_rules = 0;
	time_t setuptime, rulestime;
	char fn[PATH_MAX];
	struct stat st;
	alertrec_t *awalk, *atmp;
	alertgroup_t *gwalk, *gtmp;
	int i;

	MEMDEFINE(fn);

	setuptime = rulestime = 0;
	sprintf(fn, "%s/etc/bbwarnsetup.cfg", xgetenv("BBHOME"));
	if (stat(fn, &st) == 0) setuptime = st.st_mtime;
	sprintf(fn, "%s/etc/bbwarnrules.cfg", xgetenv("BBHOME"));
	if (stat(fn, &st) == 0) rulestime = st.st_mtime;
	if ((tstamp_setup == setuptime) && (tstamp_rules == rulestime)) {
		MEMUNDEFINE(fn);
		return;
	}

	tstamp_setup = setuptime; tstamp_rules = rulestime;
	awalk = alertrecs;
	while (awalk) {
		atmp = awalk;
		awalk = awalk->next;
		for (i=0; (i<7); i++) if (atmp->items[i]) xfree(atmp->items[i]);
		for (i=0; (i<2); i++) if (atmp->havepattern[i]) regfree(&atmp->hostpattern[i]);
		xfree(atmp);
	}
	if (unmatched) {
		for (i=0; (i<7); i++) if (unmatched->items[i]) xfree(unmatched->items[i]);
		for (i=0; (i<2); i++) if (unmatched->havepattern[i]) regfree(&unmatched->hostpattern[i]);
		xfree(unmatched);
	}
	gwalk = pagegroups;
	while (gwalk) {
		gtmp = gwalk;
		gwalk = gwalk->next;
		if (gtmp->groupname) xfree(gtmp->groupname);
		if (gtmp->groupval) xfree(gtmp->groupval);
		xfree(gtmp);
	}
	gwalk = hostgroups;
	while (gwalk) {
		gtmp = gwalk;
		gwalk = gwalk->next;
		if (gtmp->groupname) xfree(gtmp->groupname);
		if (gtmp->groupval) xfree(gtmp->groupval);
		xfree(gtmp);
	}
	alertrecs = NULL; unmatched = NULL; pagegroups = NULL; hostgroups = NULL;

	load_warnsetup();
	load_warnrules();
	replace_groupnames(0, "hg-", 0, hostgroups); /* Replace hg-* in "included hosts" spec. */
	replace_groupnames(1, "hg-", 0, hostgroups); /* Replace hg-* in "excluded hosts" spec. */
	replace_groupnames(6, "pg-", 1, pagegroups); /* Replace pg-* in recipients spec. */
	setup_regexps(0);
	setup_regexps(1);

	MEMUNDEFINE(fn);
}


alertrec_t *bbfind_alert(char *hostname, int want_default, int continued)
{
	static alertrec_t *beginrec = NULL;

	alertrec_t *a;
	regmatch_t foo[1];
	alertrec_t *result = NULL;
	int status;

	if (!continued || (beginrec == NULL)) 
		beginrec = alertrecs;
	else
		beginrec = beginrec->next;

	for (a=beginrec; (a && (result == NULL)); a=a->next) {
		dprintf("Checking '%s' against includespec '%s' excludespec '%s'\n",
			hostname, a->items[0], a->items[1]);
		status = regexec(&a->hostpattern[0], hostname, 0, foo, 0);
		if (status == 0) {
			dprintf("\tMatched include spec\n");
			result = a;
		}

		if (result && strlen(a->items[1])) {
			status = regexec(&a->hostpattern[1], hostname, 0, foo, 0);
			if (status == 0) {
				dprintf("\tMatched exclude spec\n");
				result = NULL;
			}
		}
	}

	beginrec = result;

	if ((result == NULL) && want_default) result = unmatched;
	return result;
}


#ifdef STANDALONE
int main(int argc, char *argv[])
{
	alertrec_t *a;
	int i, firstarg;

	debug = 0; firstarg = 1;
	if ((argc > 1) && (strcmp(argv[1], "--debug") == 0)) {
		debug = 1;
		firstarg++;
	}

	bbload_alerts();

	for (i=firstarg; (i<argc); i++) {
		int again = 0;
		while ((a = bbfind_alert(argv[i], 0, again)) != NULL) {
			printf("  Key        : %s\n", argv[i]);
			printf("  Hosts      : %s\n", a->items[0]);
			printf("  Ex-hosts   : %s\n", a->items[1]);
			printf("  Services   : %s\n", a->items[2]);
			printf("  Ex-Services: %s\n", a->items[3]);
			printf("  Day        : %s\n", a->items[4]);
			printf("  Time       : %s\n", a->items[5]);
			printf("  Recips     : %s\n", a->items[6]);
			printf("  Inverse    : %d\n", a->inverse);
			printf("\n");
			again = 1;
		}
		if (again == 0) printf("No matches\n");
	}
	return 0;
}
#endif

