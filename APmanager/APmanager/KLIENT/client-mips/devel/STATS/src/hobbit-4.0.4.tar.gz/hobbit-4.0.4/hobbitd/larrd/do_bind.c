/*----------------------------------------------------------------------------*/
/* Hobbit RRD handler module.                                                 */
/*                                                                            */
/* Copyright (C) 2004-2005 Henrik Storner <henrik@hswn.dk>                    */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char bind_rcsid[] = "$Id: do_bind.c,v 1.3 2005/03/25 21:15:26 henrik Exp $";

int do_bind_larrd(char *hostname, char *testname, char *msg, time_t tstamp)
{
	errprintf("bind larrd not implemented\n");
	return -1;
}

