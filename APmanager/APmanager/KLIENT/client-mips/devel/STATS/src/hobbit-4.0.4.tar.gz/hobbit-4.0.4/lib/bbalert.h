/*----------------------------------------------------------------------------*/
/* Hobbit monitor library.                                                    */
/*                                                                            */
/* This is a library module, part of libbbgen.                                */
/* It contains routines for reading and using the BB alert configuration.     */
/*                                                                            */
/* Copyright (C) 2002-2005 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#ifndef __BBALERT_H__
#define __BBALERT_H__

#include <sys/types.h>
#include <regex.h>

typedef struct alertrec_t {
	char *items[7];
	int inverse;
	regex_t hostpattern[2];
	int havepattern[2];
	struct alertrec_t *next;
} alertrec_t;

extern int bbpagedelay;
extern void bbload_alerts(void);
extern alertrec_t *bbfind_alert(char *hostname, int want_default, int continued);

#endif
