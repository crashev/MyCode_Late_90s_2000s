/*----------------------------------------------------------------------------*/
/* Hobbit checkpoint file generator.                                          */
/*                                                                            */
/* Copyright (C) 2002-2005 Henrik Storner <henrik@storner.dk>                 */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#ifndef __BBCONVERT_H__
#define __BBCONVERT_H__

extern void dump_hobbitdchk(void);

#endif

