/*----------------------------------------------------------------------------*/
/* Hobbit monitor BEA statistics tool.                                        */
/*                                                                            */
/* This is used to collect statistics from a BEA Weblogic server              */
/*                                                                            */
/* Copyright (C) 2004-2005 Henrik Storner <henrik@hswn.dk>                    */
/*                                                                            */
/* This program is released under the GNU General Public License (GPL),       */
/* version 2. See the file "COPYING" for details.                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

static char rcsid[] = "$Id: beastat.c,v 1.1 2005/05/24 15:43:02 henrik Exp henrik $";

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <pcre.h>

#include "libbbgen.h"

/*
 * The config file has multiple sections of this form:
 *
 *    [selector]
 *        bool-expression : COLOR  : MESSAGE
 *        bool-expression : COLOR  : MESSAGE
 *
 *    [selector]
 *        .....
 */
typedef struct rule_t {
	char *expression;
	int color;
	char *message;
	struct rule_t *next;
} rule_t;

typedef struct threshold_t {
	pcre *selector;
	rule_t *rules, *ruletail;
	struct threshold_t *next;
} threshold_t;


static threshold_t *thead = NULL;

void load_thresholds(char *fn)
{
	char fullfn[PATH_MAX];
	FILE *fd;
	char l[4096];
	threshold_t *ttail = NULL;

	sprintf(fullfn, "%s/etc/%s", xgetenv("BBHOME"), fn);
	fd = fopen(fullfn, "r");
	if (!fd) return;

	while (fgets(l, sizeof(l), fd)) {
		grok_input(l);
		if ((*l == '#') || (strlen(l) == 0)) continue;

		if (*l == '[') {
			threshold_t *newitem = (threshold_t *)malloc(sizeof(threshold_t));
			const char *errmsg = NULL;
			int errofs = 0;
			char *p;

			p = strchr(l, ']'); if (p) *p = '\0';
			newitem->selector = pcre_compile(l+1, PCRE_CASELESS, &errmsg, &errofs, NULL);
			if (newitem->selector) {
				newitem->rules = newitem->ruletail = NULL;
				newitem->next = NULL;

				if (ttail) {
					ttail->next = newitem;
					ttail = newitem;
				}
				else thead = ttail = newitem;
			}
			else {
				errprintf("Invalid selector '%s'\n", l);
				xfree(newitem);
			}
		}
		else if (ttail) {
			char *expression = NULL, *color = NULL, *msg = NULL;

			expression = strtok(l, ":");
			if (expression) color = strtok(NULL, ":");
			if (color) msg = strtok(NULL, ":");

			if (expression && color && msg) {
				rule_t *newitem = (rule_t *)malloc(sizeof(rule_t));

				newitem->expression = strdup(expression);
				newitem->color = parse_color(color);
				newitem->message = strdup(msg);
				newitem->next = NULL;

				if (ttail->ruletail) {
					ttail->ruletail->next = newitem;
					ttail->ruletail = newitem;
				}
				else ttail->rules = ttail->ruletail = newitem;
			}
			else {
				errprintf("Invalid rule\n");
			}
		}
	}

	fclose(fd);
}


int eval_thresholds(char *selector, valuefunc_t getvalue, char **resultstr)
{
	int v = getvalue("foo");

	return v;
}
