./ourmon -c 3000000  -r 3million*.dmp -m /tmp/mon.lite -f ./ourmon.conf 
