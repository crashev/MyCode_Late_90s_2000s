diff ~mrourmon/bin/daily.pl daily.pl
diff ~mrourmon/bin/makepics.pl makepics.pl
diff ~mrourmon/bin/monbackup.pl monbackup.pl
diff ~mrourmon/bin/ombatchip.pl ombatchip.pl
diff ~mrourmon/bin/ombatchipsrc.pl ombatchipsrc.pl
diff ~mrourmon/bin/ombatchsyn.pl ombatchsyn.pl
diff ~mrourmon/bin/omupdate.pl omupdate.pl
diff ~mrourmon/bin/tcpworm.pl tcpworm.pl
