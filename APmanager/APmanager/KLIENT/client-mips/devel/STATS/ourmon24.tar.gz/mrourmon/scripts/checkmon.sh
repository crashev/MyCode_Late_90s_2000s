#!/bin/bash
# "top" script for watching mon.lite file
while true
do
clear
sleep 30
cat /mnt/mon.lite
done
