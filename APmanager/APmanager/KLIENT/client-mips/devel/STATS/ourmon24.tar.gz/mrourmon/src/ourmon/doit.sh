./ourmon -a 10 -i lo0 -m /tmp/mon.lite -f ./ourmon.conf 
